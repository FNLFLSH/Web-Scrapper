# Horizon Scanner

This project scrapes articles from AccountingToday and saves them to AWS DynamoDB.

## Local Setup

1. Create a `.env` file in the root directory with your AWS credentials:
   ```
   AWS_REGION=us-east-1
   AWS_ACCESS_KEY_ID=your_access_key
   AWS_SECRET_ACCESS_KEY=your_secret_key
   ```

2. Run the deploy script:
   ```bash
   bash deploy.sh
   ```

## AWS Lambda Deployment

### Prerequisites
- AWS CLI installed and configured
- AWS Lambda function created in the AWS Console

### Steps to Deploy

1. **Package the Lambda Function**

   Create a deployment package by zipping the necessary files:
   ```bash
   cd horizon_scanner
   zip -r ../lambda_deployment.zip .
   ```

2. **Update the Lambda Function**

   Use the AWS CLI to update your Lambda function with the new code:
   ```bash
   aws lambda update-function-code --function-name YourLambdaFunctionName --zip-file fileb://../lambda_deployment.zip
   ```

3. **Configure Environment Variables**

   In the AWS Lambda console, set the following environment variables:
   - `AWS_REGION`
   - `AWS_ACCESS_KEY_ID`
   - `AWS_SECRET_ACCESS_KEY`

4. **Test the Lambda Function**

   Use the AWS Lambda console to test the function with a sample event.

## Project Structure

```
horizon_scanner/
├── main.py                  # Entry point for local execution
├── lambda_function.py       # Entry point for AWS Lambda
├── db_utils.py              # Handles DynamoDB writes
├── requirements.txt         # Python dependencies
├── deploy.sh                # Bash script for local setup and run
├── aws/
│   └── config.py            # AWS credentials/config loader
└── scrapers/
    └── accounting_today.py  # Example scraper for AccountingToday
``` 