import json
from scrapers.accounting_today import scrape_accounting_today
from db_utils import save_bulk

def lambda_handler(event, context):
    articles = scrape_accounting_today()
    save_bulk(articles)
    return {
        'statusCode': 200,
        'body': json.dumps('Scraper completed successfully!')
    } 