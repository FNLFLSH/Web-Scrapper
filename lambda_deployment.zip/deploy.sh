#!/bin/bash
set -e

echo "[1/4] Setting up virtual environment..."
python3 -m venv venv
source venv/bin/activate

echo "[2/4] Installing requirements..."
pip install -r requirements.txt

echo "[3/4] Running scraper..."
python main.py

echo "[4/4] Done. Check your DynamoDB table!" 