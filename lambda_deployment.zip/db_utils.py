from aws.config import get_dynamodb_resource
import uuid
from datetime import datetime

dynamodb = get_dynamodb_resource()
table = dynamodb.Table('horizon_articles')

def save_article(article):
    article['article_id'] = str(uuid.uuid4())
    article['scraped_at'] = datetime.utcnow().isoformat()
    table.put_item(Item=article)

def save_bulk(articles):
    for a in articles:
        save_article(a) 