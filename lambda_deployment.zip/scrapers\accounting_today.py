import requests
from bs4 import BeautifulSoup

def scrape_accounting_today():
    url = 'https://www.accountingtoday.com/news'
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    articles = []
    for item in soup.select('.ListingResults-item'):
        title_tag = item.find('h3')
        link_tag = item.find('a')
        if title_tag and link_tag:
            articles.append({
                'title': title_tag.get_text(strip=True),
                'url': link_tag['href'],
                'source': 'AccountingToday',
                'category': 'accounting'
            })
    return articles 